package de.vocalremover.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.OutputStream

/** Speichert Ergebnisse unter Musik/Vocal Remover (interner Speicher). */
object Exporter {
    const val FOLDER = "Vocal Remover"

    /** z. B. "Mein Song [Vocals-128BPM-Am].mp3" */
    fun fileName(input: InputInfo, stem: String, music: MusicInfo?, format: ExportFormat): String {
        val tag = if (music != null && music.bpm > 0) "$stem-${music.bpm}BPM-${music.key}" else stem
        val safeBase = input.baseName.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(150)
        return "$safeBase [$tag].${format.ext}"
    }

    suspend fun save(ctx: Context, wav: File, name: String, format: ExportFormat): Uri =
        withContext(Dispatchers.IO) {
            val resolver = ctx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, name)
                put(MediaStore.Audio.Media.TITLE, name.substringBeforeLast('.'))
                put(MediaStore.Audio.Media.MIME_TYPE, format.mime)
                put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/" + FOLDER)
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = resolver.insert(collection, values)
                ?: throw Exception("Datei konnte im Musik-Ordner nicht angelegt werden.")
            try {
                resolver.openOutputStream(uri)!!.use { out ->
                    when (format) {
                        ExportFormat.WAV -> wav.inputStream().use { it.copyTo(out, 1 shl 20) }
                        ExportFormat.MP3 -> encodeMp3(wav, out)
                    }
                }
                values.clear()
                values.put(MediaStore.Audio.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                uri
            } catch (e: Exception) {
                runCatching { resolver.delete(uri, null, null) }
                throw e
            }
        }

    private fun encodeMp3(wav: File, out: OutputStream) {
        val handle = Lame.nativeInit(SAMPLE_RATE, 2, 320)
        if (handle == 0L) throw Exception("MP3-Encoder konnte nicht gestartet werden.")
        try {
            WavReader(wav).use { reader ->
                val block = 1152 * 16
                val l = FloatArray(block); val r = FloatArray(block)
                val mp3 = ByteArray((block * 1.25).toInt() + 7200)
                while (true) {
                    val n = reader.read(l, r, block)
                    if (n <= 0) break
                    val bytes = Lame.nativeEncode(handle, l, r, n, mp3)
                    if (bytes < 0) throw Exception("Fehler beim MP3-Kodieren ($bytes).")
                    out.write(mp3, 0, bytes)
                }
                val bytes = Lame.nativeFlush(handle, mp3)
                if (bytes > 0) out.write(mp3, 0, bytes)
            }
        } finally {
            Lame.nativeClose(handle)
        }
    }
}
