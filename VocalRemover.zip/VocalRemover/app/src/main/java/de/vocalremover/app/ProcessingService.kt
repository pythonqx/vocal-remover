package de.vocalremover.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

/**
 * Laeuft als Vordergrunddienst mit Benachrichtigung, damit die Trennung auch weiterlaeuft,
 * wenn die App im Hintergrund ist oder der Bildschirm aus ist.
 */
class ProcessingService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastNotify = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                job?.cancel()
                return START_NOT_STICKY
            }
            ACTION_DOWNLOAD, ACTION_START -> {
                if (job?.isActive == true) return START_NOT_STICKY
                goForeground("Wird vorbereitet …", -1f)
                val input = (AppState.phase.value as? Phase.Ready)?.input
                    ?: (AppState.phase.value as? Phase.Failed)?.input
                val separate = intent.action == ACTION_START && input != null
                job = scope.launch { run(if (separate) input else null) }
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private suspend fun run(input: InputInfo?) {
        acquireWakeLock()
        val started = System.currentTimeMillis()
        try {
            // 1) Modell (einmalig)
            if (!ModelManager.isReady(this)) {
                update(input, Step.DOWNLOAD, 0f, "Einmaliger Download, ca. 900 MB")
                ModelManager.download(this) { done, total ->
                    val p = if (total > 0) done.toFloat() / total else -1f
                    val mb = done / (1024 * 1024)
                    val detail = if (total > 0) "$mb von ${total / (1024 * 1024)} MB" else "$mb MB"
                    update(input, Step.DOWNLOAD, p, detail)
                }
            }
            AppState.modelReady.value = true
            if (input == null) {
                AppState.phase.value = Phase.Idle
                return
            }

            // 2) Datei dekodieren
            val work = workDir(this).apply { deleteRecursively(); mkdirs() }
            val raw = File(work, "input.raw")
            update(input, Step.DECODE, 0f, input.name)
            AudioDecoder.decode(this, input.uri, raw) { p -> update(input, Step.DECODE, p, input.name) }

            // 3) Trennen
            val vocals = File(work, "vocals.wav")
            val instrumental = File(work, "instrumental.wav")
            update(input, Step.SEPARATE, -1f, "KI-Modell wird geladen …")
            val sepStart = System.currentTimeMillis()
            Separator(ModelManager.file(this)).use { sep ->
                sep.separate(raw, vocals, instrumental) { done, total ->
                    val p = done.toFloat() / total
                    val detail = buildString {
                        append("Abschnitt ${minOf(done + 1, total)} von $total")
                        if (done > 0 && done < total) {
                            val perChunk = (System.currentTimeMillis() - sepStart) / done
                            append(" · noch ca. ").append(formatDuration(perChunk * (total - done)))
                        }
                    }
                    update(input, Step.SEPARATE, p, detail)
                }
            }
            raw.delete()

            // 4) BPM und Tonart
            update(input, Step.ANALYZE, -1f, "BPM und Tonart werden ermittelt …")
            val music = runCatching { Analyzer.analyze(instrumental) }.getOrNull()

            val seconds = (System.currentTimeMillis() - started) / 1000
            AppState.phase.value = Phase.Done(input, vocals, instrumental, music, seconds)
            notifyFinished("Fertig: ${input.baseName}", "Vocals und Instrumental sind bereit.")
        } catch (e: CancellationException) {
            AppState.phase.value = if (input != null) Phase.Ready(input) else Phase.Idle
        } catch (e: OutOfMemoryError) {
            AppState.phase.value = Phase.Failed(input, "Nicht genug Arbeitsspeicher. Bitte andere Apps schliessen und erneut versuchen.")
        } catch (e: Throwable) {
            AppState.phase.value = Phase.Failed(input, e.message ?: e.toString())
            notifyFinished("Trennung fehlgeschlagen", e.message ?: "Unbekannter Fehler")
        } finally {
            releaseWakeLock()
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun update(input: InputInfo?, step: Step, progress: Float, detail: String) {
        AppState.phase.value = Phase.Working(input, step, progress, detail)
        val now = System.currentTimeMillis()
        if (now - lastNotify > 1000) {
            lastNotify = now
            val title = when (step) {
                Step.DOWNLOAD -> "KI-Modell wird heruntergeladen"
                Step.DECODE -> "Datei wird vorbereitet"
                Step.SEPARATE -> "Song wird getrennt"
                Step.ANALYZE -> "BPM und Tonart"
            }
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFY_ID, buildNotification(title, detail, progress))
        }
    }

    private fun goForeground(text: String, progress: Float) {
        createChannels()
        val type = if (Build.VERSION.SDK_INT >= 35) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING
        else ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        ServiceCompat.startForeground(this, NOTIFY_ID, buildNotification("Vocal Remover", text, progress), type)
    }

    private fun buildNotification(title: String, text: String, progress: Float): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val cancel = PendingIntent.getService(
            this, 1, Intent(this, ProcessingService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_PROGRESS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Abbrechen", cancel)
            .setProgress(1000, (progress.coerceAtLeast(0f) * 1000).toInt(), progress < 0f)
            .build()
    }

    private fun notifyFinished(title: String, text: String) {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(this, CHANNEL_DONE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        getSystemService(NotificationManager::class.java).notify(NOTIFY_DONE_ID, n)
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_PROGRESS, "Fortschritt", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CHANNEL_DONE, "Fertig", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VocalRemover:separation").apply {
            setReferenceCounted(false)
            acquire(6 * 60 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    override fun onDestroy() {
        scope.cancel()
        releaseWakeLock()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "de.vocalremover.app.START"
        const val ACTION_DOWNLOAD = "de.vocalremover.app.DOWNLOAD"
        const val ACTION_CANCEL = "de.vocalremover.app.CANCEL"
        private const val CHANNEL_PROGRESS = "progress"
        private const val CHANNEL_DONE = "done"
        private const val NOTIFY_ID = 1
        private const val NOTIFY_DONE_ID = 2

        fun workDir(ctx: Context) = File(ctx.filesDir, "work")

        fun start(ctx: Context, action: String) {
            ctx.startForegroundService(Intent(ctx, ProcessingService::class.java).setAction(action))
        }

        fun cancel(ctx: Context) {
            ctx.startService(Intent(ctx, ProcessingService::class.java).setAction(ACTION_CANCEL))
        }

        fun formatDuration(ms: Long): String {
            val s = (ms / 1000).coerceAtLeast(1)
            return if (s < 60) "$s Sek." else if (s < 3600) "${(s + 30) / 60} Min." else "${s / 3600} Std. ${(s % 3600) / 60} Min."
        }
    }
}
