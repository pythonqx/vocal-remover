package de.vocalremover.app

import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

/** Die vom Nutzer gewaehlte Audiodatei. */
data class InputInfo(
    val uri: Uri,
    val name: String,
    val sizeBytes: Long,
    val durationMs: Long,
) {
    /** Dateiname ohne Endung, z. B. "Mein Song" aus "Mein Song.mp3". */
    val baseName: String get() = name.substringBeforeLast('.', name).ifBlank { "Song" }
}

/** Ergebnis der BPM- und Tonart-Erkennung. */
data class MusicInfo(val bpm: Int, val key: String)

enum class Step { DOWNLOAD, DECODE, SEPARATE, ANALYZE }

sealed interface Phase {
    data object Idle : Phase
    data class Ready(val input: InputInfo) : Phase
    data class Working(
        val input: InputInfo?,
        val step: Step,
        val progress: Float,      // 0..1, negativ = unbestimmt
        val detail: String,
    ) : Phase
    data class Done(
        val input: InputInfo,
        val vocals: File,
        val instrumental: File,
        val music: MusicInfo?,
        val seconds: Long,
    ) : Phase
    data class Failed(val input: InputInfo?, val message: String) : Phase
}

enum class ExportFormat(val label: String, val ext: String, val mime: String) {
    MP3("MP3 320 kbps", "mp3", "audio/mpeg"),
    WAV("WAV 16-bit", "wav", "audio/x-wav"),
}

/** Zentrale Zustandsablage, die von Oberflaeche und Hintergrunddienst geteilt wird. */
object AppState {
    val phase = MutableStateFlow<Phase>(Phase.Idle)
    val modelReady = MutableStateFlow(false)
    /** Kurze Statusmeldung beim Speichern (null = nichts anzeigen). */
    val exportMessage = MutableStateFlow<String?>(null)
    val exporting = MutableStateFlow(false)
}
