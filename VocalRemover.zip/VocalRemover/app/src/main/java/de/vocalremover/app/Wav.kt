package de.vocalremover.app

import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

const val WAV_HEADER = 44

/** Schreibt 16-bit Stereo-WAV mit 44.100 Hz. Die Groessenangaben werden beim Schliessen ergaenzt. */
class WavWriter(private val file: File) : Closeable {
    private val out = BufferedOutputStream(FileOutputStream(file), 1 shl 20)
    private var dataBytes = 0L
    private var bytes = ByteArray(0)

    init { out.write(header(0)) }

    /** Schreibt [frames] Stereo-Frames aus getrennten Kanaelen (Werte -1..1). */
    fun write(left: FloatArray, right: FloatArray, offset: Int, frames: Int) {
        val need = frames * 4
        if (bytes.size < need) bytes = ByteArray(need)
        var j = 0
        for (i in offset until offset + frames) {
            val l = toPcm(left[i]); val r = toPcm(right[i])
            bytes[j] = l.toByte(); bytes[j + 1] = (l shr 8).toByte()
            bytes[j + 2] = r.toByte(); bytes[j + 3] = (r shr 8).toByte()
            j += 4
        }
        out.write(bytes, 0, need)
        dataBytes += need
    }

    private fun toPcm(v: Float): Int {
        val s = (v * 32767f).let { if (it > 32767f) 32767f else if (it < -32768f) -32768f else it }
        return Math.round(s)
    }

    override fun close() {
        out.close()
        RandomAccessFile(file, "rw").use { it.seek(0); it.write(header(dataBytes)) }
    }

    companion object {
        fun header(dataBytes: Long, sampleRate: Int = SAMPLE_RATE, channels: Int = 2): ByteArray {
            val b = ByteBuffer.allocate(WAV_HEADER).order(ByteOrder.LITTLE_ENDIAN)
            b.put("RIFF".toByteArray()); b.putInt((36 + dataBytes).toInt())
            b.put("WAVE".toByteArray()); b.put("fmt ".toByteArray())
            b.putInt(16); b.putShort(1); b.putShort(channels.toShort())
            b.putInt(sampleRate); b.putInt(sampleRate * channels * 2)
            b.putShort((channels * 2).toShort()); b.putShort(16)
            b.put("data".toByteArray()); b.putInt(dataBytes.toInt())
            return b.array()
        }
    }
}

/** Liest 16-bit Stereo-WAV-Dateien, die von [WavWriter] erzeugt wurden, blockweise. */
class WavReader(file: File) : Closeable {
    private val raf = RandomAccessFile(file, "r")
    val frames: Long = (raf.length() - WAV_HEADER) / 4
    private var pos = 0L
    private var bytes = ByteArray(0)

    init { raf.seek(WAV_HEADER.toLong()) }

    /** Liest bis zu [maxFrames] Frames in getrennte Kanaele; gibt die Anzahl gelesener Frames zurueck. */
    fun read(left: FloatArray, right: FloatArray, maxFrames: Int): Int {
        val n = minOf(maxFrames.toLong(), frames - pos).toInt()
        if (n <= 0) return 0
        val need = n * 4
        if (bytes.size < need) bytes = ByteArray(need)
        raf.readFully(bytes, 0, need)
        for (i in 0 until n) {
            val j = i * 4
            left[i] = ((bytes[j].toInt() and 0xff) or (bytes[j + 1].toInt() shl 8)).toShort() / 32768f
            right[i] = ((bytes[j + 2].toInt() and 0xff) or (bytes[j + 3].toInt() shl 8)).toShort() / 32768f
        }
        pos += n
        return n
    }

    override fun close() = raf.close()
}
