package de.vocalremover.app

import android.content.Context
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Laedt das KI-Modell (Mel-Band RoFormer deux von becruily, speichersparend umgebaut)
 * einmalig herunter. Abgebrochene Downloads werden fortgesetzt.
 */
object ModelManager {
    private const val FILE_NAME = "mel_band_roformer_deux_lowmem.onnx"
    private const val MIN_SIZE = 800L * 1024 * 1024

    fun file(ctx: Context) = File(ctx.filesDir, FILE_NAME)
    private fun partFile(ctx: Context) = File(ctx.filesDir, "$FILE_NAME.part")

    fun isReady(ctx: Context): Boolean = file(ctx).length() > MIN_SIZE

    suspend fun download(ctx: Context, onProgress: (done: Long, total: Long) -> Unit) {
        if (isReady(ctx)) return
        val part = partFile(ctx)
        var attempt = 0
        while (true) {
            try {
                downloadOnce(part, onProgress)
                break
            } catch (e: Exception) {
                currentCoroutineContext().ensureActive()
                attempt++
                if (attempt >= 5) throw Exception(
                    "Download des Modells fehlgeschlagen. Bitte Internetverbindung pruefen und erneut versuchen. (${e.message})"
                )
                kotlinx.coroutines.delay(3000L * attempt)
            }
        }
        if (part.length() < MIN_SIZE) {
            part.delete()
            throw Exception("Die heruntergeladene Modelldatei ist unvollstaendig. Bitte erneut versuchen.")
        }
        if (!part.renameTo(file(ctx))) throw Exception("Modelldatei konnte nicht gespeichert werden.")
        AppState.modelReady.value = true
    }

    private suspend fun downloadOnce(part: File, onProgress: (Long, Long) -> Unit) {
        val have = if (part.exists()) part.length() else 0L
        val conn = (URL(BuildConfig.MODEL_URL).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = true
            connectTimeout = 20_000
            readTimeout = 60_000
            if (have > 0) setRequestProperty("Range", "bytes=$have-")
        }
        try {
            val code = conn.responseCode
            val append = code == HttpURLConnection.HTTP_PARTIAL && have > 0
            if (code != HttpURLConnection.HTTP_OK && !append) {
                throw Exception("Server antwortet mit Code $code")
            }
            val start = if (append) have else 0L
            val length = conn.contentLengthLong
            val total = if (length > 0) start + length else -1L
            conn.inputStream.use { input ->
                FileOutputStream(part, append).use { out ->
                    val buf = ByteArray(1 shl 16)
                    var done = start
                    var lastReport = 0L
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (done - lastReport > (2 shl 20)) {
                            lastReport = done
                            onProgress(done, total)
                        }
                    }
                    if (total > 0 && done < total) throw Exception("Verbindung abgebrochen")
                    onProgress(done, total)
                }
            }
        } finally {
            conn.disconnect()
        }
    }
}
