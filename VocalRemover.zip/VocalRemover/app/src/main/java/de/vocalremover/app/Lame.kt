package de.vocalremover.app

/** Schnittstelle zum MP3-Encoder LAME (in C, siehe src/main/cpp). */
object Lame {
    init { System.loadLibrary("vrlame") }

    @JvmStatic external fun nativeInit(sampleRate: Int, channels: Int, bitrateKbps: Int): Long
    @JvmStatic external fun nativeEncode(handle: Long, left: FloatArray, right: FloatArray, frames: Int, out: ByteArray): Int
    @JvmStatic external fun nativeFlush(handle: Long, out: ByteArray): Int
    @JvmStatic external fun nativeClose(handle: Long)
}
