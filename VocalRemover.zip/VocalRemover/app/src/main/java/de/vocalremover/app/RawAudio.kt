package de.vocalremover.app

import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.min

/**
 * Zwischendateien: Stereo, interleaved (L, R, L, R ...), 32-bit Float, Little Endian, 44.100 Hz.
 * So muss nie ein ganzer Song im Arbeitsspeicher liegen (wichtig fuer 25-Minuten-Dateien).
 */
const val SAMPLE_RATE = 44_100

class RawWriter(file: File) : Closeable {
    private val channel: FileChannel = FileOutputStream(file).channel
    private val buffer: ByteBuffer = ByteBuffer.allocateDirect(1 shl 18).order(ByteOrder.LITTLE_ENDIAN)

    /** Schreibt [count] Floats aus [data] ab [offset]. */
    fun write(data: FloatArray, count: Int, offset: Int = 0) {
        var i = offset
        val end = offset + count
        while (i < end) {
            val n = min(end - i, buffer.remaining() / 4)
            buffer.asFloatBuffer().put(data, i, n)
            buffer.position(buffer.position() + n * 4)
            i += n
            if (buffer.remaining() < 4) flush()
        }
    }

    private fun flush() {
        buffer.flip()
        while (buffer.hasRemaining()) channel.write(buffer)
        buffer.clear()
    }

    override fun close() {
        flush()
        channel.close()
    }
}

class RawReader(file: File) : Closeable {
    private val raf = RandomAccessFile(file, "r")
    private val channel: FileChannel = raf.channel
    private var buffer: ByteBuffer = ByteBuffer.allocateDirect(1 shl 20).order(ByteOrder.LITTLE_ENDIAN)

    /** Anzahl Stereo-Frames in der Datei. */
    val frames: Long = channel.size() / 8

    /**
     * Liest [frameCount] Stereo-Frames ab [frameStart] interleaved nach [dest].
     * Alles hinter dem Dateiende wird mit Stille (0) aufgefuellt.
     */
    fun read(frameStart: Long, frameCount: Int, dest: FloatArray) {
        val bytes = frameCount * 8
        if (buffer.capacity() < bytes) {
            buffer = ByteBuffer.allocateDirect(bytes).order(ByteOrder.LITTLE_ENDIAN)
        }
        buffer.clear()
        buffer.limit(bytes)
        var pos = frameStart * 8
        while (buffer.hasRemaining()) {
            val n = channel.read(buffer, pos)
            if (n <= 0) break
            pos += n
        }
        val floats = buffer.position() / 4
        buffer.flip()
        buffer.asFloatBuffer().get(dest, 0, floats)
        if (floats < frameCount * 2) dest.fill(0f, floats, frameCount * 2)
    }

    override fun close() {
        channel.close()
        raf.close()
    }
}
