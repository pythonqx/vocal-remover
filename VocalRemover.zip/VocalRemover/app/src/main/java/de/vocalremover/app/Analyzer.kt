package de.vocalremover.app

import java.io.File
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Ermittelt Tempo (BPM) und Tonart aus dem Instrumental.
 * Tempo: Einsatz-Erkennung (Spectral Flux) + Autokorrelation.
 * Tonart: Chroma-Verteilung, verglichen mit Dur-/Moll-Profilen (Krumhansl-Kessler).
 */
object Analyzer {
    private const val SR = 22_050
    private const val MAX_SECONDS = 360
    private val NAMES = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    fun analyze(instrumentalWav: File): MusicInfo? {
        val mono = loadMono(instrumentalWav) ?: return null
        if (mono.size < SR * 5) return null
        return MusicInfo(bpm = detectBpm(mono), key = detectKey(mono))
    }

    /** Liest das WAV, mischt auf Mono und halbiert die Abtastrate (44,1 kHz -> 22,05 kHz). */
    private fun loadMono(file: File): FloatArray? {
        WavReader(file).use { r ->
            val totalOut = r.frames / 2
            val maxOut = SR.toLong() * MAX_SECONDS
            val skipOut = if (totalOut > maxOut) (totalOut - maxOut) / 2 else 0L
            val count = minOf(totalOut, maxOut).toInt()
            if (count <= 0) return null
            val out = FloatArray(count)
            val l = FloatArray(8192); val rr = FloatArray(8192)
            var skip = skipOut * 2
            var o = 0
            while (o < count) {
                val n = r.read(l, rr, 8192)
                if (n <= 0) break
                var i = 0
                if (skip > 0) {
                    val s = minOf(skip, n.toLong()).toInt()
                    skip -= s; i = s
                    if (i >= n) continue
                }
                while (i + 1 < n && o < count) {
                    out[o++] = (l[i] + rr[i] + l[i + 1] + rr[i + 1]) * 0.25f
                    i += 2
                }
            }
            return if (o < count) out.copyOf(o) else out
        }
    }

    // ---------- Tempo ----------

    fun detectBpm(x: FloatArray): Int {
        val n = 1024; val hop = 128
        val fps = SR.toDouble() / hop
        val frames = (x.size - n) / hop
        if (frames < 100) return 0
        val win = hann(n)
        val re = FloatArray(n); val im = FloatArray(n)
        val maxBin = (8000.0 * n / SR).toInt()
        var prev = FloatArray(maxBin)
        val cur = FloatArray(maxBin)
        val flux = FloatArray(frames)
        for (f in 0 until frames) {
            val off = f * hop
            for (i in 0 until n) { re[i] = x[off + i] * win[i]; im[i] = 0f }
            fft(re, im)
            var sum = 0f
            for (b in 1 until maxBin) {
                val m = ln(1f + 100f * sqrt(re[b] * re[b] + im[b] * im[b]))
                cur[b] = m
                val d = m - prev[b]
                if (d > 0) sum += d
            }
            flux[f] = sum
            val t = prev; prev = cur.copyOf(); t.fill(0f)
        }
        // lokalen Mittelwert abziehen, nur positive Anteile behalten
        val avgLen = (fps * 0.5).toInt().coerceAtLeast(1)
        val env = FloatArray(frames)
        var run = 0.0
        for (i in 0 until frames) {
            run += flux[i]
            if (i >= avgLen) run -= flux[i - avgLen]
            val mean = run / minOf(i + 1, avgLen)
            env[i] = max(0f, (flux[i] - mean).toFloat())
        }
        // Autokorrelation im Bereich 50..220 BPM, gewichtet um 120 BPM
        val minLag = (fps * 60 / 220).toInt()
        val maxLag = (fps * 60 / 50).toInt()
        val ac = DoubleArray(maxLag + 2)
        for (lag in minLag..maxLag + 1) {
            var s = 0.0
            for (i in 0 until frames - lag) s += env[i] * env[i + lag]
            ac[lag] = s / (frames - lag)
        }
        var bestLag = minLag
        var best = -1.0
        for (lag in minLag..maxLag) {
            val bpm = 60 * fps / lag
            val prior = exp(-0.5 * (log2(bpm / 120.0) / 0.9).let { it * it })
            // Harmonische (doppelte Periode) mit einbeziehen fuer stabilere Treffer
            val harmonic = if (lag * 2 <= maxLag + 1) 0.5 * ac[lag * 2] else 0.0
            val score = (ac[lag] + harmonic) * prior
            if (score > best) { best = score; bestLag = lag }
        }
        // Feinabstimmung per Parabel-Interpolation
        var lagF = bestLag.toDouble()
        if (bestLag in (minLag + 1) until maxLag) {
            val a = ac[bestLag - 1]; val b = ac[bestLag]; val c = ac[bestLag + 1]
            val d = a - 2 * b + c
            if (d < 0) lagF += 0.5 * (a - c) / d
        }
        var bpm = 60 * fps / lagF
        while (bpm < 70) bpm *= 2
        while (bpm >= 180) bpm /= 2
        return bpm.roundToInt()
    }

    // ---------- Tonart ----------

    private val MAJOR = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
    private val MINOR = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)

    fun detectKey(x: FloatArray): String {
        val n = 8192; val hop = 4096
        val frames = (x.size - n) / hop
        if (frames < 4) return "?"
        val win = hann(n)
        val re = FloatArray(n); val im = FloatArray(n)
        val minBin = (60.0 * n / SR).toInt().coerceAtLeast(1)
        val maxBin = (2100.0 * n / SR).toInt()
        val pcOfBin = IntArray(maxBin + 1) { b ->
            if (b < minBin) -1 else {
                val f = b.toDouble() * SR / n
                val midi = 12 * log2(f / 440.0) + 69
                ((midi.roundToInt() % 12) + 12) % 12
            }
        }
        val chroma = DoubleArray(12)
        val frame = DoubleArray(12)
        for (f in 0 until frames) {
            val off = f * hop
            for (i in 0 until n) { re[i] = x[off + i] * win[i]; im[i] = 0f }
            fft(re, im)
            frame.fill(0.0)
            var energy = 0.0
            for (b in minBin..maxBin) {
                val m = sqrt((re[b] * re[b] + im[b] * im[b]).toDouble())
                frame[pcOfBin[b]] += m
                energy += m
            }
            if (energy < 1e-3) continue
            var norm = 0.0
            for (v in frame) norm += v * v
            norm = sqrt(norm)
            for (p in 0 until 12) chroma[p] += frame[p] / norm
        }
        var bestScore = Double.NEGATIVE_INFINITY
        var bestName = "?"
        for (root in 0 until 12) {
            val maj = corr(chroma, MAJOR, root)
            if (maj > bestScore) { bestScore = maj; bestName = NAMES[root] }
            val min = corr(chroma, MINOR, root)
            if (min > bestScore) { bestScore = min; bestName = NAMES[root] + "m" }
        }
        return bestName
    }

    private fun corr(chroma: DoubleArray, profile: DoubleArray, root: Int): Double {
        val mx = chroma.average(); val mp = profile.average()
        var sxy = 0.0; var sxx = 0.0; var syy = 0.0
        for (i in 0 until 12) {
            val a = chroma[(i + root) % 12] - mx
            val b = profile[i] - mp
            sxy += a * b; sxx += a * a; syy += b * b
        }
        return sxy / sqrt(sxx * syy + 1e-12)
    }

    // ---------- Hilfsfunktionen ----------

    private fun hann(n: Int) = FloatArray(n) { (0.5 - 0.5 * cos(2 * PI * it / n)).toFloat() }

    /** In-place Radix-2-FFT. */
    fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                var t = re[i]; re[i] = re[j]; re[j] = t
                t = im[i]; im[i] = im[j]; im[j] = t
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2 * PI / len
            val wr = cos(ang); val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until len / 2) {
                    val a = i + k; val b = a + len / 2
                    val tr = (re[b] * cr - im[b] * ci).toFloat()
                    val ti = (re[b] * ci + im[b] * cr).toFloat()
                    re[b] = re[a] - tr; im[b] = im[a] - ti
                    re[a] += tr; im[a] += ti
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr; cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
