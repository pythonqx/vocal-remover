package de.vocalremover.app

import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Palette {
    val Ink = Color(0xFF0C0D13)
    val Mint = Color(0xFF3EE6A0)
    val Violet = Color(0xFF8B6CFF)
    val Text = Color(0xFFF2F3F7)
    val Muted = Color(0xFF9A9CAB)
    val Danger = Color(0xFFFF7A8A)
    val Accent = Brush.linearGradient(listOf(Mint, Violet))
}

/** Dunkler Hintergrund mit zwei weichen Farbflaechen, damit das Glas etwas zum Durchscheinen hat. */
@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Palette.Ink)) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            drawCircle(
                Brush.radialGradient(listOf(Palette.Mint.copy(alpha = 0.22f), Color.Transparent), Offset(w * 0.05f, h * 0.18f), w * 0.85f),
                radius = w * 0.85f, center = Offset(w * 0.05f, h * 0.18f),
            )
            drawCircle(
                Brush.radialGradient(listOf(Palette.Violet.copy(alpha = 0.26f), Color.Transparent), Offset(w * 0.95f, h * 0.62f), w * 0.9f),
                radius = w * 0.9f, center = Offset(w * 0.95f, h * 0.62f),
            )
        }
        content()
    }
}

/** Glas-Optik: halbtransparente Flaeche, heller Rand oben links, dunkler unten rechts. */
fun Modifier.glass(shape: Shape, accentBorder: Boolean = false, tint: Float = 0.09f): Modifier =
    this.clip(shape)
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = tint + 0.03f), Color.White.copy(alpha = tint * 0.45f))))
        .border(
            width = if (accentBorder) 1.5.dp else 1.dp,
            brush = if (accentBorder) Palette.Accent else Brush.linearGradient(
                listOf(Color.White.copy(alpha = 0.38f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.16f))
            ),
            shape = shape,
        )

@Composable
fun GlassCard(modifier: Modifier = Modifier, padding: Dp = 20.dp, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.glass(RoundedCornerShape(26.dp)).padding(padding), content = content)
}

@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accent: Boolean = false,
    enabled: Boolean = true,
    height: Dp = 56.dp,
    fontSize: Int = 17,
    leading: (@Composable RowScope.() -> Unit)? = null,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, label = "press")
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .scale(scale)
            .height(height)
            .glass(shape, accentBorder = accent && enabled, tint = if (pressed) 0.16f else if (accent) 0.12f else 0.08f)
            .clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
            .padding(PaddingValues(horizontal = 26.dp)),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        leading?.invoke(this)
        Text(
            text,
            color = if (enabled) Palette.Text else Palette.Muted,
            fontSize = fontSize.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}

/** Zwei oder mehr Optionen nebeneinander, die aktive ist als Glas-Pille hinterlegt. */
@Composable
fun <T> GlassSegmented(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.glass(RoundedCornerShape(50), tint = 0.05f).padding(4.dp)) {
        options.forEach { opt ->
            val active = opt == selected
            Box(
                Modifier
                    .weight(1f)
                    .height(42.dp)
                    .then(if (active) Modifier.glass(RoundedCornerShape(50), accentBorder = true, tint = 0.14f) else Modifier.clip(RoundedCornerShape(50)))
                    .clickable { onSelect(opt) },
                contentAlignment = Alignment.Center,
            ) {
                Text(label(opt), color = if (active) Palette.Text else Palette.Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun GradientProgress(progress: Float, modifier: Modifier = Modifier) {
    androidx.compose.foundation.layout.BoxWithConstraints(
        modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.08f))
    ) {
        if (progress >= 0f) {
            Box(Modifier.fillMaxWidth(progress.coerceIn(0.02f, 1f)).height(8.dp).clip(RoundedCornerShape(50)).background(Palette.Accent))
        } else {
            val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "busy")
            val x by t.animateFloat(
                initialValue = -0.3f, targetValue = 1f,
                animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                    androidx.compose.animation.core.tween(1400, easing = androidx.compose.animation.core.LinearEasing)
                ),
                label = "x",
            )
            Box(
                Modifier.offset(x = maxWidth * x).width(maxWidth * 0.3f).height(8.dp)
                    .clip(RoundedCornerShape(50)).background(Palette.Accent)
            )
        }
    }
}
