package de.vocalremover.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Fuehrt das Modell in 8-Sekunden-Abschnitten aus. Die Abschnitte ueberlappen sich zur Haelfte
 * und werden mit weichen Uebergaengen wieder zusammengesetzt, damit keine Schnitte hoerbar sind.
 */
class Separator(modelFile: File) : AutoCloseable {
    private val env = OrtEnvironment.getEnvironment()
    private val session: OrtSession
    private val inputName: String

    init {
        val opts = OrtSession.SessionOptions().apply {
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(1, 8))
            setCPUArenaAllocator(false)
            setMemoryPatternOptimization(false)
        }
        session = env.createSession(modelFile.absolutePath, opts)
        inputName = session.inputNames.first()
    }

    suspend fun separate(
        input: File,
        vocalsOut: File,
        instrumentalOut: File,
        onChunk: (done: Int, total: Int) -> Unit,
    ) {
        val c = CHUNK
        val step = c / 2
        val fade = c / 8
        val window = FloatArray(c) { i ->
            val a = minOf(i, c - 1 - i)
            if (a < fade) (a + 1).toFloat() / (fade + 1) else 1f
        }

        RawReader(input).use { reader ->
            val frames = reader.frames
            val total = if (frames <= c) 1 else (((frames - c) + step - 1) / step + 1).toInt()
            val accV = Array(2) { FloatArray(c) }
            val accI = Array(2) { FloatArray(c) }
            val accW = FloatArray(c)
            val interleaved = FloatArray(c * 2)
            val outL = FloatArray(c); val outR = FloatArray(c)
            val outL2 = FloatArray(c); val outR2 = FloatArray(c)
            val inBuf = ByteBuffer.allocateDirect(c * 2 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            val shape = longArrayOf(1, 2, c.toLong())

            WavWriter(vocalsOut).use { vw ->
                WavWriter(instrumentalOut).use { iw ->
                    var s = 0L
                    var k = 0
                    onChunk(0, total)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        reader.read(s, c, interleaved)
                        inBuf.clear()
                        for (i in 0 until c) inBuf.put(i, interleaved[2 * i])
                        for (i in 0 until c) inBuf.put(c + i, interleaved[2 * i + 1])
                        inBuf.rewind()

                        OnnxTensor.createTensor(env, inBuf, shape).use { tensor ->
                            session.run(mapOf(inputName to tensor)).use { result ->
                                val out = (result.get(0) as OnnxTensor).floatBuffer
                                // Ausgabe: [1, 2 Spuren, 2 Kanaele, c]; Spur 0 = Vocals, Spur 1 = Instrumental
                                for (ch in 0..1) {
                                    val vBase = ch * c
                                    val iBase = (2 + ch) * c
                                    val av = accV[ch]; val ai = accI[ch]
                                    for (i in 0 until c) {
                                        val w = window[i]
                                        av[i] += w * out.get(vBase + i)
                                        ai[i] += w * out.get(iBase + i)
                                    }
                                }
                                for (i in 0 until c) accW[i] += window[i]
                            }
                        }

                        val last = s + c >= frames
                        val emit = if (last) (frames - s).toInt() else step
                        for (i in 0 until emit) {
                            val w = accW[i]
                            outL[i] = accV[0][i] / w; outR[i] = accV[1][i] / w
                            outL2[i] = accI[0][i] / w; outR2[i] = accI[1][i] / w
                        }
                        vw.write(outL, outR, 0, emit)
                        iw.write(outL2, outR2, 0, emit)
                        k++
                        onChunk(k, total)
                        if (last) break

                        for (arr in listOf(accV[0], accV[1], accI[0], accI[1], accW)) {
                            System.arraycopy(arr, step, arr, 0, c - step)
                            java.util.Arrays.fill(arr, c - step, c, 0f)
                        }
                        s += step
                    }
                }
            }
        }
    }

    override fun close() {
        session.close()
    }

    companion object {
        /** 8 Sekunden bei 44.100 Hz – so erwartet es das Modell. */
        const val CHUNK = 352_800
    }
}
