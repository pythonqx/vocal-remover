package de.vocalremover.app

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.nio.ByteOrder

/**
 * Dekodiert MP3, WAV, FLAC, M4A/AAC, OGG, OPUS usw. mit den Android-eigenen Decodern
 * und schreibt das Ergebnis als Stereo-Float mit 44.100 Hz in eine Zwischendatei.
 */
object AudioDecoder {

    /** @return Anzahl der geschriebenen Stereo-Frames */
    suspend fun decode(ctx: Context, uri: Uri, out: File, onProgress: (Float) -> Unit): Long {
        val extractor = MediaExtractor()
        extractor.setDataSource(ctx, uri, null)
        var track = -1
        for (i in 0 until extractor.trackCount) {
            val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) { track = i; break }
        }
        if (track < 0) {
            extractor.release()
            throw Exception("In dieser Datei wurde keine Audiospur gefunden.")
        }
        extractor.selectTrack(track)
        val inFormat = extractor.getTrackFormat(track)
        val mime = inFormat.getString(MediaFormat.KEY_MIME)!!
        val durationUs = if (inFormat.containsKey(MediaFormat.KEY_DURATION)) inFormat.getLong(MediaFormat.KEY_DURATION) else 0L

        val codec = try {
            MediaCodec.createDecoderByType(mime)
        } catch (e: Exception) {
            extractor.release()
            throw Exception("Dieses Audioformat ($mime) wird vom Handy nicht unterstuetzt.")
        }
        codec.configure(inFormat, null, null, 0)
        codec.start()

        var sampleRate = inFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = inFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var pcmFloat = false
        var resampler = Resampler(sampleRate, SAMPLE_RATE)

        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        var written = 0L
        var stereo = FloatArray(0)

        RawWriter(out).use { writer ->
            val emit: (FloatArray, Int) -> Unit = { data, frames ->
                writer.write(data, frames * 2)
                written += frames
            }
            try {
                while (!outputDone) {
                    currentCoroutineContext().ensureActive()
                    if (!inputDone) {
                        val ii = codec.dequeueInputBuffer(10_000)
                        if (ii >= 0) {
                            val buf = codec.getInputBuffer(ii)!!
                            val n = extractor.readSampleData(buf, 0)
                            if (n < 0) {
                                codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(ii, 0, n, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                    val oi = codec.dequeueOutputBuffer(info, 10_000)
                    when {
                        oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val f = codec.outputFormat
                            val sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            pcmFloat = f.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                                f.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                            if (sr != sampleRate) {
                                sampleRate = sr
                                resampler = Resampler(sampleRate, SAMPLE_RATE)
                            }
                        }
                        oi >= 0 -> {
                            if (info.size > 0) {
                                val buf = codec.getOutputBuffer(oi)!!
                                buf.position(info.offset)
                                buf.limit(info.offset + info.size)
                                buf.order(ByteOrder.nativeOrder())
                                val ch = channels.coerceAtLeast(1)
                                val frames: Int
                                if (pcmFloat) {
                                    val fb = buf.asFloatBuffer()
                                    frames = fb.remaining() / ch
                                    if (stereo.size < frames * 2) stereo = FloatArray(frames * 2)
                                    for (i in 0 until frames) {
                                        val l = fb.get(i * ch)
                                        val r = if (ch > 1) fb.get(i * ch + 1) else l
                                        stereo[2 * i] = l; stereo[2 * i + 1] = r
                                    }
                                } else {
                                    val sb = buf.asShortBuffer()
                                    frames = sb.remaining() / ch
                                    if (stereo.size < frames * 2) stereo = FloatArray(frames * 2)
                                    for (i in 0 until frames) {
                                        val l = sb.get(i * ch) / 32768f
                                        val r = if (ch > 1) sb.get(i * ch + 1) / 32768f else l
                                        stereo[2 * i] = l; stereo[2 * i + 1] = r
                                    }
                                }
                                resampler.process(stereo, frames, emit)
                                if (durationUs > 0) {
                                    onProgress((info.presentationTimeUs.toFloat() / durationUs).coerceIn(0f, 1f))
                                }
                            }
                            codec.releaseOutputBuffer(oi, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                        }
                    }
                }
                resampler.flush(emit)
            } finally {
                runCatching { codec.stop() }
                codec.release()
                extractor.release()
            }
        }
        if (written == 0L) throw Exception("Die Datei enthaelt keine abspielbaren Audiodaten.")
        onProgress(1f)
        return written
    }
}

/**
 * Einfacher Stereo-Resampler (kubische Hermite-Interpolation) fuer Dateien,
 * die nicht in 44.100 Hz vorliegen, z. B. 48.000 Hz.
 */
class Resampler(private val inRate: Int, private val outRate: Int) {
    private val passthrough = inRate == outRate
    private val step = inRate.toDouble() / outRate
    private var hist = FloatArray(4096)   // interleaved Stereo-Puffer
    private var histFrames = 0
    private var pos = 1.0                 // Leseposition im Puffer (Frames)
    private var out = FloatArray(0)

    init { histFrames = 1 }               // ein Stille-Frame als Startwert

    fun process(data: FloatArray, frames: Int, emit: (FloatArray, Int) -> Unit) {
        if (passthrough) { emit(data, frames); return }
        ensure(histFrames + frames)
        System.arraycopy(data, 0, hist, histFrames * 2, frames * 2)
        histFrames += frames
        render(emit)
    }

    fun flush(emit: (FloatArray, Int) -> Unit) {
        if (passthrough) return
        ensure(histFrames + 3)
        java.util.Arrays.fill(hist, histFrames * 2, (histFrames + 3) * 2, 0f)
        histFrames += 3
        render(emit)
    }

    private fun ensure(frames: Int) {
        if (hist.size < frames * 2) hist = hist.copyOf(frames * 2 + 8192)
    }

    private fun render(emit: (FloatArray, Int) -> Unit) {
        val maxOut = ((histFrames - pos) / step).toInt() + 2
        if (out.size < maxOut * 2) out = FloatArray(maxOut * 2)
        var n = 0
        while (pos.toInt() + 2 < histFrames) {
            val i = pos.toInt()
            val t = (pos - i).toFloat()
            for (c in 0..1) {
                val y0 = hist[(i - 1) * 2 + c]
                val y1 = hist[i * 2 + c]
                val y2 = hist[(i + 1) * 2 + c]
                val y3 = hist[(i + 2) * 2 + c]
                val a = -0.5f * y0 + 1.5f * y1 - 1.5f * y2 + 0.5f * y3
                val b = y0 - 2.5f * y1 + 2f * y2 - 0.5f * y3
                val cc = -0.5f * y0 + 0.5f * y2
                out[n * 2 + c] = ((a * t + b) * t + cc) * t + y1
            }
            n++
            pos += step
        }
        if (n > 0) emit(out, n)
        // alles vor (i - 1) wird nicht mehr gebraucht
        val keepFrom = (pos.toInt() - 1).coerceAtLeast(0)
        if (keepFrom > 0) {
            System.arraycopy(hist, keepFrom * 2, hist, 0, (histFrames - keepFrom) * 2)
            histFrames -= keepFrom
            pos -= keepFrom
        }
    }
}
