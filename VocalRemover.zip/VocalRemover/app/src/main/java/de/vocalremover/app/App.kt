package de.vocalremover.app

import android.app.Application
import android.content.Context
import android.os.Build
import java.io.File

/** Speichert Abstuerze in einer Datei, damit sie beim naechsten Start angezeigt werden koennen. */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            runCatching { CrashLog.write(this, "Absturz im Thread \"${thread.name}\"", e) }
            previous?.uncaughtException(thread, e)
        }
    }
}

object CrashLog {
    private fun file(ctx: Context) = File(ctx.filesDir, "crash.txt")

    fun write(ctx: Context, title: String, e: Throwable) {
        val text = buildString {
            append(title).append('\n')
            append("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}\n")
            append("App-Build ${BuildConfig.VERSION_CODE}\n\n")
            append(e.stackTraceToString())
        }
        file(ctx).writeText(text.take(12_000))
    }

    fun read(ctx: Context): String? = file(ctx).takeIf { it.exists() }?.readText()
    fun clear(ctx: Context) { file(ctx).delete() }
}
