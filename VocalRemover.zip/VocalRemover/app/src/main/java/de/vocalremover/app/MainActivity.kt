package de.vocalremover.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        AppState.modelReady.value = ModelManager.isReady(this)
        handleShare(intent)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                GlassBackground { AppScreen() }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    /** Erlaubt "Teilen" einer Audiodatei aus anderen Apps direkt in diese App. */
    private fun handleShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        @Suppress("DEPRECATION")
        val uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) ?: return
        selectFile(this, uri)
    }
}

/** Setzt eine neue Eingabedatei, sofern gerade nichts verarbeitet wird. */
fun selectFile(ctx: Context, uri: Uri) {
    if (AppState.phase.value is Phase.Working) return
    runCatching {
        ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    var name = "Song"
    var size = 0L
    runCatching {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0) size = c.getLong(si)
            }
        }
    }
    val duration = runCatching {
        MediaMetadataRetriever().run {
            setDataSource(ctx, uri)
            val d = extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            release(); d
        }
    }.getOrDefault(0L)
    AppState.exportMessage.value = null
    AppState.phase.value = Phase.Ready(InputInfo(uri, name, size, duration))
}

@Composable
private fun AppScreen() {
    val ctx = LocalContext.current
    val phase by AppState.phase.collectAsState()
    val modelReady by AppState.modelReady.collectAsState()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) selectFile(ctx, uri)
    }
    val pick = { picker.launch(arrayOf("audio/*")) }

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val startWork: (String) -> Unit = { action ->
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        ProcessingService.start(ctx, action)
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(48.dp))
        Text(
            "Vocals aus jedem Song entfernen",
            color = Palette.Text, fontSize = 30.sp, lineHeight = 36.sp,
            fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Trennt deinen Song offline in Vocals und Instrumental",
            color = Palette.Muted, fontSize = 16.sp, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(40.dp))

        AnimatedContent(
            targetState = phase,
            contentKey = { it::class },
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "phase",
        ) { p ->
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                when (p) {
                    is Phase.Idle -> IdleContent(pick)
                    is Phase.Ready -> ReadyContent(p.input, pick) { startWork(ProcessingService.ACTION_START) }
                    is Phase.Working -> WorkingContent(p) { ProcessingService.cancel(ctx) }
                    is Phase.Done -> DoneContent(p, pick)
                    is Phase.Failed -> FailedContent(p, pick) { startWork(ProcessingService.ACTION_START) }
                }
            }
        }

        if (!modelReady && phase !is Phase.Working) {
            Spacer(Modifier.height(28.dp))
            ModelHint { startWork(ProcessingService.ACTION_DOWNLOAD) }
        }

        Spacer(Modifier.height(32.dp))
        Text(
            "Modell: Mel-Band RoFormer deux von becruily (CC BY-NC 4.0)",
            color = Palette.Muted.copy(alpha = 0.7f), fontSize = 12.sp, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun PickButton(pick: () -> Unit, label: String = "Datei auswählen") {
    GlassButton(
        label, pick, accent = true, height = 64.dp, fontSize = 19,
        leading = { Text("+", color = Palette.Text, fontSize = 24.sp, modifier = Modifier.padding(end = 12.dp)) },
    )
}

@Composable
private fun IdleContent(pick: () -> Unit) {
    PickButton(pick)
    Spacer(Modifier.height(14.dp))
    Text("MP3, WAV, FLAC, M4A, OGG und mehr", color = Palette.Muted, fontSize = 14.sp)
}

@Composable
private fun FileCard(input: InputInfo, trailing: @Composable () -> Unit = {}) {
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(Palette.Accent),
                contentAlignment = Alignment.Center,
            ) { Text("♪", color = Palette.Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(input.name, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(2.dp))
                val parts = buildList {
                    if (input.durationMs > 0) add(formatTime(input.durationMs))
                    if (input.sizeBytes > 0) add(String.format("%.1f MB", input.sizeBytes / 1048576.0))
                }
                Text(parts.joinToString("   "), color = Palette.Muted, fontSize = 14.sp)
            }
            trailing()
        }
    }
}

@Composable
private fun ReadyContent(input: InputInfo, pick: () -> Unit, start: () -> Unit) {
    FileCard(input)
    Spacer(Modifier.height(24.dp))
    GlassButton("Trennung starten", start, accent = true, height = 60.dp, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(10.dp))
    TextAction("Andere Datei wählen", pick)
}

@Composable
private fun WorkingContent(p: Phase.Working, cancel: () -> Unit) {
    if (p.input != null) {
        FileCard(p.input)
        Spacer(Modifier.height(16.dp))
    }
    GlassCard(Modifier.fillMaxWidth(), padding = 22.dp) {
        Column {
            val title = when (p.step) {
                Step.DOWNLOAD -> "KI-Modell wird heruntergeladen"
                Step.DECODE -> "Datei wird vorbereitet"
                Step.SEPARATE -> "Song wird getrennt"
                Step.ANALYZE -> "BPM und Tonart"
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text(title, color = Palette.Text, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                if (p.progress >= 0f) {
                    Text("${(p.progress * 100).toInt()} %", color = Palette.Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(14.dp))
            GradientProgress(p.progress)
            Spacer(Modifier.height(12.dp))
            Text(p.detail, color = Palette.Muted, fontSize = 14.sp)
        }
    }
    Spacer(Modifier.height(16.dp))
    Text(
        "Du kannst die App verlassen, die Arbeit läuft im Hintergrund weiter.",
        color = Palette.Muted, fontSize = 13.sp, textAlign = TextAlign.Center,
    )
    Spacer(Modifier.height(16.dp))
    GlassButton("Abbrechen", cancel, height = 48.dp, fontSize = 15)
}

@Composable
private fun DoneContent(p: Phase.Done, pick: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val exporting by AppState.exporting.collectAsState()
    val message by AppState.exportMessage.collectAsState()
    var format by remember { mutableStateOf(ExportFormat.MP3) }
    val player = rememberPlayer()

    p.music?.let { m ->
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            InfoPill("${m.bpm}", "BPM", Modifier.weight(1f))
            InfoPill(m.key, "Tonart", Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
    }

    StemRow("Instrumental", p.instrumental, player)
    Spacer(Modifier.height(12.dp))
    StemRow("Vocals", p.vocals, player)
    Spacer(Modifier.height(24.dp))

    GlassSegmented(
        options = ExportFormat.entries.toList(), selected = format, label = { it.label },
        onSelect = { format = it }, modifier = Modifier.fillMaxWidth(),
    )
    Spacer(Modifier.height(14.dp))

    val save: (List<Pair<String, File>>) -> Unit = { stems ->
        scope.launch {
            AppState.exporting.value = true
            AppState.exportMessage.value = "Wird gespeichert …"
            try {
                val names = stems.map { (stem, file) ->
                    val name = Exporter.fileName(p.input, stem, p.music, format)
                    Exporter.save(ctx, file, name, format)
                    name
                }
                AppState.exportMessage.value = "Gespeichert in Musik/${Exporter.FOLDER}:\n" + names.joinToString("\n")
            } catch (e: Exception) {
                AppState.exportMessage.value = "Speichern fehlgeschlagen: ${e.message}"
            } finally {
                AppState.exporting.value = false
            }
        }
    }
    GlassButton(
        "Beide speichern", { save(listOf("Instrumental" to p.instrumental, "Vocals" to p.vocals)) },
        accent = true, enabled = !exporting, height = 58.dp, modifier = Modifier.fillMaxWidth(),
    )
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassButton("Nur Instrumental", { save(listOf("Instrumental" to p.instrumental)) }, enabled = !exporting, height = 48.dp, fontSize = 14, modifier = Modifier.weight(1f))
        GlassButton("Nur Vocals", { save(listOf("Vocals" to p.vocals)) }, enabled = !exporting, height = 48.dp, fontSize = 14, modifier = Modifier.weight(1f))
    }
    message?.let {
        Spacer(Modifier.height(14.dp))
        Text(it, color = if (it.startsWith("Speichern fehl")) Palette.Danger else Palette.Mint, fontSize = 14.sp, textAlign = TextAlign.Center)
    }
    Spacer(Modifier.height(18.dp))
    Text("Fertig in ${ProcessingService.formatDuration(p.seconds * 1000)}", color = Palette.Muted, fontSize = 13.sp)
    Spacer(Modifier.height(6.dp))
    TextAction("Neuen Song wählen") { player.stop(); pick() }
}

@Composable
private fun InfoPill(value: String, label: String, modifier: Modifier = Modifier) {
    GlassCard(modifier, padding = 14.dp) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = Palette.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Palette.Muted, fontSize = 13.sp)
        }
    }
}

@Composable
private fun StemRow(title: String, file: File, player: Player) {
    val playing = player.current == file && player.isPlaying
    GlassCard(Modifier.fillMaxWidth(), padding = 14.dp) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(46.dp)
                        .glass(CircleShape, accentBorder = playing, tint = 0.12f)
                        .clickable { player.toggle(file) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(if (playing) "❚❚" else "▶", color = Palette.Text, fontSize = if (playing) 14.sp else 17.sp)
                }
                Spacer(Modifier.width(14.dp))
                Text(title, color = Palette.Text, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                if (player.current == file) {
                    Text(formatTime(player.positionMs), color = Palette.Muted, fontSize = 13.sp)
                }
            }
            if (player.current == file) {
                Spacer(Modifier.height(10.dp))
                GradientProgress(player.fraction)
            }
        }
    }
}

@Composable
private fun FailedContent(p: Phase.Failed, pick: () -> Unit, retry: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth()) {
        Column {
            Text("Das hat nicht geklappt", color = Palette.Danger, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))
            Text(p.message, color = Palette.Text, fontSize = 14.sp)
        }
    }
    Spacer(Modifier.height(20.dp))
    if (p.input != null) {
        GlassButton("Erneut versuchen", retry, accent = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        TextAction("Andere Datei wählen", pick)
    } else {
        PickButton(pick)
    }
}

@Composable
private fun ModelHint(download: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth().widthIn(max = 520.dp)) {
        Column {
            Text("KI-Modell noch nicht geladen", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text(
                "Einmalig ca. 900 MB, danach funktioniert alles offline. WLAN empfohlen. Der Download startet sonst automatisch beim ersten Trennen.",
                color = Palette.Muted, fontSize = 13.sp,
            )
            Spacer(Modifier.height(12.dp))
            GlassButton("Jetzt herunterladen", download, height = 44.dp, fontSize = 14)
        }
    }
}

@Composable
private fun TextAction(text: String, onClick: () -> Unit) {
    Text(
        text, color = Palette.Muted, fontSize = 15.sp,
        modifier = Modifier.clip(CircleShape).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
    )
}

fun formatTime(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) String.format("%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    else String.format("%d:%02d", s / 60, s % 60)
}

/** Kleiner Player zum Vorhören der Ergebnisse. */
class Player {
    private var mp: MediaPlayer? = null
    var current by mutableStateOf<File?>(null); private set
    var isPlaying by mutableStateOf(false); private set
    var positionMs by mutableStateOf(0L); private set
    var fraction by mutableFloatStateOf(0f); private set

    fun toggle(file: File) {
        val p = mp
        if (current == file && p != null) {
            if (p.isPlaying) p.pause() else p.start()
            isPlaying = p.isPlaying
            return
        }
        stop()
        mp = runCatching {
            MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnCompletionListener { this@Player.isPlaying = false; this@Player.fraction = 1f }
                prepare()
                start()
            }
        }.getOrNull() ?: return
        current = file
        isPlaying = true
    }

    fun tick() {
        val p = mp ?: return
        runCatching {
            positionMs = p.currentPosition.toLong()
            fraction = if (p.duration > 0) p.currentPosition.toFloat() / p.duration else 0f
        }
    }

    fun stop() {
        mp?.release(); mp = null
        current = null; isPlaying = false; positionMs = 0; fraction = 0f
    }
}

@Composable
private fun rememberPlayer(): Player {
    val player = remember { Player() }
    LaunchedEffect(player) {
        while (true) { player.tick(); delay(250) }
    }
    DisposableEffect(player) { onDispose { player.stop() } }
    return player
}
