#include <jni.h>
#include <stdlib.h>
#include <stdint.h>
#include "lame.h"

/* Kleine JNI-Bruecke zu LAME: init -> encode (mehrfach) -> flush -> close */

JNIEXPORT jlong JNICALL
Java_de_vocalremover_app_Lame_nativeInit(JNIEnv *env, jclass clazz,
                                                jint sampleRate, jint channels, jint bitrateKbps) {
    lame_global_flags *gf = lame_init();
    if (gf == NULL) return 0;
    lame_set_in_samplerate(gf, sampleRate);
    lame_set_out_samplerate(gf, sampleRate);
    lame_set_num_channels(gf, channels);
    lame_set_mode(gf, channels == 1 ? MONO : JOINT_STEREO);
    lame_set_VBR(gf, vbr_off);
    lame_set_brate(gf, bitrateKbps);
    lame_set_quality(gf, 2); /* 0 = beste, 9 = schnellste; 2 = sehr gut */
    lame_set_write_id3tag_automatic(gf, 0);
    lame_set_bWriteVbrTag(gf, 0);
    if (lame_init_params(gf) < 0) {
        lame_close(gf);
        return 0;
    }
    return (jlong) (intptr_t) gf;
}

JNIEXPORT jint JNICALL
Java_de_vocalremover_app_Lame_nativeEncode(JNIEnv *env, jclass clazz, jlong handle,
                                                  jfloatArray left, jfloatArray right, jint frames,
                                                  jbyteArray out) {
    lame_global_flags *gf = (lame_global_flags *) (intptr_t) handle;
    jfloat *l = (*env)->GetFloatArrayElements(env, left, NULL);
    jfloat *r = (*env)->GetFloatArrayElements(env, right, NULL);
    jbyte *o = (*env)->GetByteArrayElements(env, out, NULL);
    jsize outSize = (*env)->GetArrayLength(env, out);
    int n = lame_encode_buffer_ieee_float(gf, l, r, frames, (unsigned char *) o, outSize);
    (*env)->ReleaseFloatArrayElements(env, left, l, JNI_ABORT);
    (*env)->ReleaseFloatArrayElements(env, right, r, JNI_ABORT);
    (*env)->ReleaseByteArrayElements(env, out, o, 0);
    return n;
}

JNIEXPORT jint JNICALL
Java_de_vocalremover_app_Lame_nativeFlush(JNIEnv *env, jclass clazz, jlong handle,
                                                 jbyteArray out) {
    lame_global_flags *gf = (lame_global_flags *) (intptr_t) handle;
    jbyte *o = (*env)->GetByteArrayElements(env, out, NULL);
    jsize outSize = (*env)->GetArrayLength(env, out);
    int n = lame_encode_flush(gf, (unsigned char *) o, outSize);
    (*env)->ReleaseByteArrayElements(env, out, o, 0);
    return n;
}

JNIEXPORT void JNICALL
Java_de_vocalremover_app_Lame_nativeClose(JNIEnv *env, jclass clazz, jlong handle) {
    lame_global_flags *gf = (lame_global_flags *) (intptr_t) handle;
    if (gf != NULL) lame_close(gf);
}
