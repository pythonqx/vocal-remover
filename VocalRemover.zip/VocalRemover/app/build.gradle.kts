plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "de.vocalremover.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "de.vocalremover.app"
        minSdk = 29
        targetSdk = 35
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }

        // Download-Adresse des Modells; wird vom GitHub-Workflow gesetzt
        val modelUrl = (project.findProperty("modelUrl") as String?) ?: ""
        buildConfigField("String", "MODEL_URL", "\"$modelUrl\"")

        externalNativeBuild {
            cmake { arguments += listOf("-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON") }
        }
    }

    ndkVersion = "27.0.12077973"

    signingConfigs {
        create("release") {
            storeFile = file("release.jks")
            storePassword = "vocalremover"
            keyAlias = "vocalremover"
            keyPassword = "vocalremover"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        // QNN laedt seine Bibliotheken per Dateipfad, daher entpackt installieren
        jniLibs { useLegacyPackaging = true }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.microsoft.onnxruntime:onnxruntime-android-qnn:1.22.0")
}
