"""
Baut das Modell speichersparend um: Die Attention ueber die Zeitachse wird in Portionen
zu je 100 Zeitschritten berechnet statt alles auf einmal. Das Ergebnis ist rechnerisch
identisch, braucht aber deutlich weniger Arbeitsspeicher.
Aufruf: python lowmem.py original.onnx ausgabe.onnx
"""
import onnx, numpy as np
from onnx import helper, numpy_helper
CH=100
NQ=801
import sys
m=onnx.load(sys.argv[1]); g=m.graph
nodes=list(g.node)
cons={}
for n in nodes:
  for i in n.input: cons.setdefault(i,[]).append(n)
inits={i.name for i in g.initializer}
consts={n.output[0]:n for n in nodes if n.op_type=='Constant'}
def C(name,vals,dt=np.int64):
  g.initializer.append(numpy_helper.from_array(np.array(vals,dtype=dt),name))
C('ck_axes',[2]); C('ck_zero',[0])
starts=list(range(0,NQ,CH))
for k,s in enumerate(starts):
  C(f'ck_s{k}',[s]); C(f'ck_e{k}',[s+CH if k<len(starts)-1 else NQ])
plan={}; skip=set()
for n in nodes:
  if n.op_type=='Einsum' and n.attribute[0].s==b'b h i d, b h j d -> b h i j' and n.name.split('/')[1].endswith('.0'):
    mul=cons[n.output[0]][0]; sm=cons[mul.output[0]][0]; av=cons[sm.output[0]][0]
    assert mul.op_type=='Mul' and sm.op_type=='Softmax' and av.op_type=='Einsum', (mul.op_type,sm.op_type,av.op_type)
    assert av.attribute[0].s==b'b h i j, b h j d -> b h i d'
    assert len(cons[n.output[0]])==1 and len(cons[mul.output[0]])==1 and len(cons[sm.output[0]])==1
    assert av.input[0]==sm.output[0]
    plan[av.name]=(n,mul,sm,av); skip.update([n.name,mul.name,sm.name])
axis=None
new=[]; count=0
for n in nodes:
  if n.name in skip: continue
  if n.name not in plan: new.append(n); continue
  qk,mul,sm,av=plan[n.name]
  q,kk=qk.input; v=av.input[1]
  scale=[i for i in mul.input if i!=qk.output[0]][0]
  ax=[a.i for a in sm.attribute if a.name=='axis']; ax=ax[0] if ax else -1
  axis=ax
  p=qk.name+'_ck'
  new.append(helper.make_node('Mul',[q,scale],[p+'_qs'],name=p+'_qs'))
  new.append(helper.make_node('Transpose',[kk],[p+'_kT'],name=p+'_kT',perm=[0,1,3,2]))
  outs=[]; prev=None
  for k in range(len(starts)):
    s=f'ck_s{k}'; e=f'ck_e{k}'
    if prev is not None:
      # künstliche Abhängigkeit: Abschnitt k startet erst, wenn k-1 fertig ist
      new.append(helper.make_node('Shape',[prev],[f'{p}_sh{k}'],name=f'{p}_sh{k}',start=0,end=1))
      new.append(helper.make_node('Mul',[f'{p}_sh{k}','ck_zero'],[f'{p}_z{k}'],name=f'{p}_z{k}'))
      new.append(helper.make_node('Add',[s,f'{p}_z{k}'],[f'{p}_s{k}'],name=f'{p}_s{k}'))
      new.append(helper.make_node('Add',[e,f'{p}_z{k}'],[f'{p}_e{k}'],name=f'{p}_e{k}'))
      s=f'{p}_s{k}'; e=f'{p}_e{k}'
    new.append(helper.make_node('Slice',[p+'_qs',s,e,'ck_axes'],[f'{p}_q{k}'],name=f'{p}_q{k}'))
    new.append(helper.make_node('MatMul',[f'{p}_q{k}',p+'_kT'],[f'{p}_sc{k}'],name=f'{p}_sc{k}'))
    new.append(helper.make_node('Softmax',[f'{p}_sc{k}'],[f'{p}_p{k}'],name=f'{p}_p{k}',axis=ax))
    new.append(helper.make_node('MatMul',[f'{p}_p{k}',v],[f'{p}_o{k}'],name=f'{p}_o{k}'))
    outs.append(f'{p}_o{k}'); prev=f'{p}_o{k}'
  new.append(helper.make_node('Concat',outs,list(av.output),name=p+'_cat',axis=2))
  count+=1
del g.node[:]; g.node.extend(new)
print('Attention-Bloecke umgebaut:',count,'softmax axis',axis,'opset',[o.version for o in m.opset_import])
onnx.save(m,sys.argv[2])
